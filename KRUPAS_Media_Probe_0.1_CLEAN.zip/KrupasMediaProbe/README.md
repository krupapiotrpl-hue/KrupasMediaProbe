# KRUPAS Media Probe 0.1

Diagnostyczna aplikacja dla radia Roko K706 (Android 13).

## Co sprawdza
- aktywne `MediaSession` (tytuł, wykonawca, album, stan odtwarzania),
- dane publikowane przez powiadomienia od aplikacji Bluetooth/media,
- starsze broadcasty `metachanged` / `playstatechanged`.

## Test na radiu
1. Zainstaluj APK.
2. Uruchom `KRUPAS Media Probe`.
3. Naciśnij `DOSTĘP DO POWIADOMIEŃ` i zezwól aplikacji.
4. Połącz telefon z radiem przez Bluetooth i włącz utwór.
5. Wróć do aplikacji i sprawdź sekcję `ACTIVE MEDIA SESSIONS` oraz `OSTATNI ODCZYT`.

Jeśli tytuł/wykonawca pojawi się w którejkolwiek sekcji, kolejna wersja może przekazać dane do ESP32-S3 i dalej do GID/CID.
